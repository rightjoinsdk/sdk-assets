/*
 * Copyright 2010-2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *  http://aws.amazon.com/apache2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

package com.rightjoin.clientsdk.model;


public class LoginSchema {
    /**
     * User&#39;s email
     */
    @com.google.gson.annotations.SerializedName("user_email")
    private String userEmail = null;
    /**
     * User&#39;s password
     */
    @com.google.gson.annotations.SerializedName("password")
    private String password = null;
    /**
     * Call Back function
     */
    @com.google.gson.annotations.SerializedName("call_back")
    private String callBack = null;

    /**
     * User&#39;s email
     *
     * @return userEmail
     **/
    public String getUserEmail() {
        return userEmail;
    }

    /**
     * Sets the value of userEmail.
     *
     * @param userEmail the new value
     */
    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    /**
     * User&#39;s password
     *
     * @return password
     **/
    public String getPassword() {
        return password;
    }

    /**
     * Sets the value of password.
     *
     * @param password the new value
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Call Back function
     *
     * @return callBack
     **/
    public String getCallBack() {
        return callBack;
    }

    /**
     * Sets the value of callBack.
     *
     * @param callBack the new value
     */
    public void setCallBack(String callBack) {
        this.callBack = callBack;
    }

}
