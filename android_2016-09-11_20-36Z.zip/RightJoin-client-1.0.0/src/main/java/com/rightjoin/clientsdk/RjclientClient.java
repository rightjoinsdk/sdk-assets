/*
 * Copyright 2010-2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *  http://aws.amazon.com/apache2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

package com.rightjoin.clientsdk;

import java.util.*;

import com.rightjoin.clientsdk.model.Empty;
import com.rightjoin.clientsdk.model.DistributionRequest;
import com.rightjoin.clientsdk.model.IngestionRequest;
import com.rightjoin.clientsdk.model.LoginSchema;


@com.amazonaws.mobileconnectors.apigateway.annotation.Service(endpoint = "https://o6jdukbnhd.execute-api.us-west-2.amazonaws.com/dev")
public interface RjclientClient {


    /**
     * A generic invoker to invoke any API Gateway endpoint.
     * @param request
     * @return ApiResponse
     */
    com.amazonaws.mobileconnectors.apigateway.ApiResponse execute(com.amazonaws.mobileconnectors.apigateway.ApiRequest request);
    
    /**
     * 
     * 
     * @param accessToken 
     * @param dataPackageName 
     * @return Empty
     */
    @com.amazonaws.mobileconnectors.apigateway.annotation.Operation(path = "/dataelement", method = "GET")
    Empty dataelementGet(
            @com.amazonaws.mobileconnectors.apigateway.annotation.Parameter(name = "access_token", location = "query")
            String accessToken,
            @com.amazonaws.mobileconnectors.apigateway.annotation.Parameter(name = "data_package_name", location = "query")
            String dataPackageName);
    
    /**
     * 
     * 
     * @return Empty
     */
    @com.amazonaws.mobileconnectors.apigateway.annotation.Operation(path = "/dataelement", method = "OPTIONS")
    Empty dataelementOptions();
    
    /**
     * 
     * 
     * @param accessToken 
     * @return Empty
     */
    @com.amazonaws.mobileconnectors.apigateway.annotation.Operation(path = "/datapackage", method = "GET")
    Empty datapackageGet(
            @com.amazonaws.mobileconnectors.apigateway.annotation.Parameter(name = "access_token", location = "query")
            String accessToken);
    
    /**
     * 
     * 
     * @return Empty
     */
    @com.amazonaws.mobileconnectors.apigateway.annotation.Operation(path = "/datapackage", method = "OPTIONS")
    Empty datapackageOptions();
    
    /**
     * 
     * 
     * @param accessToken 
     * @return Empty
     */
    @com.amazonaws.mobileconnectors.apigateway.annotation.Operation(path = "/distribution", method = "GET")
    Empty distributionGet(
            @com.amazonaws.mobileconnectors.apigateway.annotation.Parameter(name = "access_token", location = "query")
            String accessToken);
    
    /**
     * 
     * 
     * @param body 
     * @return Empty
     */
    @com.amazonaws.mobileconnectors.apigateway.annotation.Operation(path = "/distribution", method = "POST")
    Empty distributionPost(
            DistributionRequest body);
    
    /**
     * 
     * 
     * @return Empty
     */
    @com.amazonaws.mobileconnectors.apigateway.annotation.Operation(path = "/distribution", method = "OPTIONS")
    Empty distributionOptions();
    
    /**
     * 
     * 
     * @param accessToken 
     * @return Empty
     */
    @com.amazonaws.mobileconnectors.apigateway.annotation.Operation(path = "/ingestion", method = "GET")
    Empty ingestionGet(
            @com.amazonaws.mobileconnectors.apigateway.annotation.Parameter(name = "access_token", location = "query")
            String accessToken);
    
    /**
     * 
     * 
     * @param body 
     * @return Empty
     */
    @com.amazonaws.mobileconnectors.apigateway.annotation.Operation(path = "/ingestion", method = "POST")
    Empty ingestionPost(
            IngestionRequest body);
    
    /**
     * 
     * 
     * @return Empty
     */
    @com.amazonaws.mobileconnectors.apigateway.annotation.Operation(path = "/ingestion", method = "OPTIONS")
    Empty ingestionOptions();
    
    /**
     * 
     * 
     * @param body 
     * @return Empty
     */
    @com.amazonaws.mobileconnectors.apigateway.annotation.Operation(path = "/user", method = "POST")
    Empty userPost(
            LoginSchema body);
    
    /**
     * 
     * 
     * @return Empty
     */
    @com.amazonaws.mobileconnectors.apigateway.annotation.Operation(path = "/user", method = "OPTIONS")
    Empty userOptions();
    
}

