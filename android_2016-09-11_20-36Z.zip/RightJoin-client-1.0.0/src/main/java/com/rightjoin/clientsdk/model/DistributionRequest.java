/*
 * Copyright 2010-2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *  http://aws.amazon.com/apache2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

package com.rightjoin.clientsdk.model;


public class DistributionRequest {
    /**
     * User&#39;s Temp Access Token for the current session
     */
    @com.google.gson.annotations.SerializedName("access_token")
    private String accessToken = null;
    /**
     * Token for the Ingested Data Package
     */
    @com.google.gson.annotations.SerializedName("ingestion_token")
    private String ingestionToken = null;
    /**
     * A valid distribution&#39;s data package name
     */
    @com.google.gson.annotations.SerializedName("data_package_name")
    private String dataPackageName = null;

    /**
     * User&#39;s Temp Access Token for the current session
     *
     * @return accessToken
     **/
    public String getAccessToken() {
        return accessToken;
    }

    /**
     * Sets the value of accessToken.
     *
     * @param accessToken the new value
     */
    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    /**
     * Token for the Ingested Data Package
     *
     * @return ingestionToken
     **/
    public String getIngestionToken() {
        return ingestionToken;
    }

    /**
     * Sets the value of ingestionToken.
     *
     * @param ingestionToken the new value
     */
    public void setIngestionToken(String ingestionToken) {
        this.ingestionToken = ingestionToken;
    }

    /**
     * A valid distribution&#39;s data package name
     *
     * @return dataPackageName
     **/
    public String getDataPackageName() {
        return dataPackageName;
    }

    /**
     * Sets the value of dataPackageName.
     *
     * @param dataPackageName the new value
     */
    public void setDataPackageName(String dataPackageName) {
        this.dataPackageName = dataPackageName;
    }

}
